import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

DEVS = list(map(int, os.getenv("DEVS", "2010120067").split()))

API_ID = int(os.getenv("API_ID", "33366894"))

API_HASH = os.getenv("API_HASH", "d25a099e762e9bad00a6c7b602aa9dc7")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8334553448:AAEQvCyrc7R19dg6YBk9dkcnFB2IMSOpXJE")

OWNER_ID = int(os.getenv("OWNER_ID", "2010120067"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763 -1002044997044 -1002022625433 -1002050846285 -1002400165299 -1002416419679 -1001473548283").split()))

RMBG_API = os.getenv("RMBG_API", "MA2sUZ4HdAfBegL36HiG4BUG")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://hadzzz:wjwhwhwhhshsgwhwhwgwg@cluster0.osx6jbl.mongodb.net/?appName=Cluster0")
LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003915356236"))
